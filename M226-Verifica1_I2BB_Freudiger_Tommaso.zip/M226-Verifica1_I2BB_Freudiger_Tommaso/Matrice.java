import java.util.Scanner;

/*
Autore: Tommaso Freudiger
Classe: I2BB

Stampare una matrice n x n, dove n è un numero intero fornito dall'utente tramite l'uso dello Scanner. Ogni cella della matrice deve contenere la somma degli indici di riga e colonna corrispondenti.

Esempio: "java Matrice"
Dammi un numero: 3
Risultato:
0 1 2
1 2 3 
2 3 4
*/

public class Matrice {
	public static void main(String[] args) {
        
		Scanner scanner = new Scanner(System.in);
		
        }       
	}	
}