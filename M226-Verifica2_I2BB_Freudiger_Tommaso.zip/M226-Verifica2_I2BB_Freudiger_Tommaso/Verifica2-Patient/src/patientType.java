public enum patientType {
    AMBULATORIALE, RICOVERATO, EMERGENZA;
}
