public class PublishingHouse {
    private String name;
    private String address;

    public String getName() {
        return name;
    }

    public String getAddress() {
        return address;
    }

    public String toString() {
        return "Publishing House{" +
                "Name='" + name + '\'' +
                ", Address=" + address +
                '}';
    }

    public PublishingHouse(String name, String address) {
        this.name = name;
        this.address = address;
    }
}
